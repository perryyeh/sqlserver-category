if exists (select * from dbo.sysobjects where id = object_id(N'[fn_Sort_Tree]') and xtype in (N'FN', N'IF', N'TF'))
drop function [fn_Sort_Tree]
GO
/*
�������Ŀ¼����
*/
CREATE FUNCTION fn_Sort_Tree
(
	@SortName nvarchar(255),--������
	@SortParentPath varchar(4000),--�����ุ·��
	@ParentPath varchar(4000),--�ϼ����ุ·��
	@iNext int
)
RETURNS nvarchar(4000)
AS
BEGIN
	DECLARE @s nvarchar(4000)
	DECLARE @i1 int,@i2 int,@i3 int
	SET @s=REPLACE(@SortParentPath,',','')
	SET @i1=LEN(@SortParentPath)-LEN(@s)
	SET @s=REPLACE(@ParentPath,',','')
	SET @i2=LEN(@ParentPath)-LEN(@s)
	SET @i3=@i1-@i2
	SET @s=''
	WHILE @i3>0
	BEGIN
		SET @i3=@i3-1
		SET @s=@s+'��'
	END

	BEGIN
		IF @iNext>0
			SET @s=@s+'��'+@SortName
		ELSE
			SET @s=@s+'��'+@SortName
	END
RETURN @s
END
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[fn_Sort_CheckComma]') and xtype in (N'FN', N'IF', N'TF'))
drop function [fn_Sort_CheckComma]
GO
/*
��ⶺ�Ÿ���
*/
CREATE FUNCTION fn_Sort_CheckComma
(
	@SortParentPath varchar(4000)--�����ุ·��
)
RETURNS int
AS
BEGIN
	DECLARE @s nvarchar(4000),@i int

	SET @s=REPLACE(@SortParentPath,',','')
	SET @i=LEN(@SortParentPath)-LEN(@s)

RETURN @i
END
GO